#!/usr/bin/env bash
cargo build --features flutter --release --target aarch64-apple-ios --lib
